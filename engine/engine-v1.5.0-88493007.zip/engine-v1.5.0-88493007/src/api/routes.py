#!/usr/bin/env python3
"""
Full Spectrum Engine API — Route definitions (v1.5.0)

24 endpoints: 18 through v1.4 plus 6 additive v1.5 enterprise-pilot endpoints.
    GET    /api/v1/health                    — Health check (enhanced: storage metadata)
    POST   /api/v1/evaluate                  — Simulation evaluation (direct mode + adapter mode)
    POST   /api/v1/runestone                 — Standalone runestone generation
    GET    /api/v1/decisions/{id}            — Decision record lookup (from SQLite)
    GET    /api/v1/audit/decisions           — Decision audit list query (v0.6)
    GET    /api/v1/audit/runestones          — Runestone audit list query (v0.6)
    GET    /api/v1/audit/runestones/{id}     — Single runestone lookup (v0.6)
    DELETE /api/v1/audit/decisions           — Data cleanup with safety valve (v0.6)
    POST   /api/v1/envelope                  — v1.2 Observer Input/Output Envelope (v1.2)
    POST   /api/v1/profile/load              — v1.3 Profile ingest (v1.3)
    GET    /api/v1/profile/{id}              — v1.3 Profile fetch (v1.3)
    POST   /api/v1/policy/load                — v1.3 Policy validate (v1.3)
    POST   /api/v1/evaluation/record         — v1.4 analyze + record immutable event (FR-01)
    POST   /api/v1/replay                    — v1.4 replay → new REPLAY event (FR-05/FR-06)
    GET    /api/v1/evaluation/events/{id}    — v1.4 fetch a single event (FR-09)
    GET    /api/v1/evaluation/events         — v1.4 list events (FR-09)
    POST   /api/v1/audit/export               — v1.4 export chain as canonical JSONL (FR-09)
    POST   /api/v1/audit/verify               — v1.4 verify chain integrity / tamper (FR-09)
    POST   /api/v1/pilot/auth/verify           — v1.5 reference-token verification
    POST   /api/v1/pilot/review                — v1.5 append-only human review
    GET    /api/v1/pilot/health                — v1.5 pilot health
    GET    /api/v1/pilot/metrics               — v1.5 pilot counters
    POST   /api/v1/pilot/connector/export      — v1.5 connector contract export
    POST   /api/v1/pilot/deploy/walkthrough    — v1.5 local deployment walkthrough

Engineering constraints:
    - API body strictly compatible with CLI output (no envelope) (P1-1)
    - Metadata goes in HTTP headers (P1-1)
    - decision_id and runestone_id strictly separated (P0-1)
    - Error codes unified 422/404/500 (P1-2)
    - risk_vector validation failure returns 422, not bare 500 (P1-3)
    - include_input_metrics defaults to false (P1-5)
    - v0.6: SQLite persistence layer, X-Storage-Mode=sqlite-persistent
    - v0.6: X-Input-Metrics-Persisted response header (NFR-16)
    - v0.6: DELETE safety valve (confirm + before/all + local-only binding)
    - v1.0: All error responses use structured format {"message", "error_code"}
"""

import hashlib
import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse

from .models import (
    EvaluateRequest,
    RunestoneRequest,
    HealthResponse,
    EnvelopeRequest,
    ProfileLoadRequest,
    PolicyLoadRequest,
    EvaluationRecordRequest,
    ReplayRequest,
    AuditExportRequest,
    AuditVerifyRequest,
    PilotAuthVerifyRequest,
    PilotReviewRequest,
    PilotConnectorExportRequest,
    PilotDeployWalkthroughRequest,
)
from .registry import get_registry
from src.governance_chain import envelope as envelope_mod

# Ensure project root is on sys.path so we can import simulate.py
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from simulate import run_simulation  # noqa: E402
from src.bridge.runestone import Runestone, RiskVector, ReasonField  # noqa: E402
from src.subject import normalize_declaration, subject_ref, SubjectDeclarationError  # noqa: E402
from src.governance_chain.profiles.registry import get_default_registry as get_profile_registry  # noqa: E402
from src.governance_chain.registry import ProfileIntegrityError  # noqa: E402

router = APIRouter(prefix="/api/v1", tags=["v1.5.0"])

# API version identifiers
API_VERSION = "1.5.0"
ENGINE_VERSION = "1.5.0"

# Required risk vector fields (must match RiskVector.to_dict())
# Note: the field name "reversibility" is retained for protocol compatibility,
# but its semantics are "irreversibility" (higher value = more irreversible).
RISK_VECTOR_FIELDS = [
    "survival_impact",
    "trust_impact",
    "meaning_impact",
    "reversibility",  # semantics: irreversibility
    "explainability",
    "diffusivity",
    "urgency",
    "uncertainty",
]


# ============================================================
# Helper functions
# ============================================================

def _generate_decision_id(scenario: dict, seed: int, subject_ref_value=None) -> str:
    """
    Generate a deterministic decision_id from scenario content and seed (P0-1).

    decision_id is the API-layer evaluation record ID, strictly separated from
    runestone_id (the audit token ID). The same scenario + seed always produces
    the same decision_id, ensuring reproducibility.
    """
    payload = json.dumps(
        {"scenario": scenario, "seed": seed, "subject_ref": subject_ref_value},
        ensure_ascii=False,
        sort_keys=True,
    ).encode("utf-8")
    return f"DEC_{hashlib.sha256(payload).hexdigest()[:16]}"


def _set_metadata_headers(
    response: Response,
    decision_id: Optional[str] = None,
    input_metrics_persisted: Optional[bool] = None,
) -> None:
    """
    Set API metadata headers on the response (P1-1).

    These are kept out of the body so the API body can be diffed against CLI output.
    v0.6: X-Storage-Mode updated to sqlite-persistent.
    v0.6: NFR-16 X-Input-Metrics-Persisted response header.
    """
    response.headers["X-Storage-Mode"] = "sqlite-persistent"
    response.headers["X-Full-Spectrum-Notice"] = "local-dev-only"
    response.headers["X-Production-Ready"] = "false"
    if decision_id:
        response.headers["X-Decision-Id"] = decision_id
    # NFR-16: X-Input-Metrics-Persisted
    if input_metrics_persisted is not None:
        response.headers["X-Input-Metrics-Persisted"] = str(input_metrics_persisted).lower()


def _validate_risk_vector(rv_dict: dict) -> None:
    """
    Validate a risk vector dict (P1-3).

    Raises 422 with a structured error when required fields are missing,
    instead of letting the RiskVector constructor throw a bare 500.
    """
    missing = [f for f in RISK_VECTOR_FIELDS if f not in rv_dict]
    if missing:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": f"Invalid risk_vector: missing fields: {missing}. Required fields: {RISK_VECTOR_FIELDS}",
                "error_code": "VALIDATION_ERROR",
            },
        )
    # Validate value types
    for field in RISK_VECTOR_FIELDS:
        val = rv_dict[field]
        if not isinstance(val, (int, float)):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "message": f"Invalid risk_vector: field '{field}' must be a number, got {type(val).__name__}",
                    "error_code": "VALIDATION_ERROR",
                },
            )


# ============================================================
# 端点 1: GET /api/v1/health
# ============================================================

@router.get("/health", response_model=HealthResponse)
async def health(request: Request, response: Response):
    """
    Health check endpoint.

    v0.6: Enhanced — original fields retained + new storage metadata.
    """
    registry = get_registry()
    _set_metadata_headers(response)

    # 判断网络暴露级别
    app = request.app
    host = getattr(app.state, "bind_host", "127.0.0.1")
    network_exposure = "local" if host in ("127.0.0.1", "localhost") else "non-local"

    # v0.6: 从 storage 获取统计信息
    storage = getattr(app.state, "storage", None)
    if storage:
        stats = storage.get_stats()
        return {
            "status": "ok",
            "version": API_VERSION,
            "engine_version": ENGINE_VERSION,
            "registered_adapters": registry.list_industries(),
            "storage_mode": stats["storage_mode"],
            "network_exposure": network_exposure,
            "db_path": stats["db_path"],
            "db_size_bytes": stats["db_size_bytes"],
            "decision_count": stats["decision_count"],
            "runestone_count": stats["runestone_count"],
            "ttl_days": stats["ttl_days"],
            "max_records": stats["max_records"],
        }

    return HealthResponse(
        status="ok",
        version=API_VERSION,
        engine_version=ENGINE_VERSION,
        registered_adapters=registry.list_industries(),
        storage_mode="sqlite-persistent",
        network_exposure=network_exposure,
    )


# ============================================================
# 端点 2: POST /api/v1/evaluate
# ============================================================

@router.post("/evaluate")
async def evaluate(req: EvaluateRequest, request: Request, response: Response):
    """
    Simulation evaluation endpoint.

    Supports two modes:
    1. Direct mode: pass a complete scenario dict
    2. Adapter mode: pass industry + metrics

    Response body is strictly equal to run_simulation() output, fully CLI-compatible.
    decision_id is returned via the X-Decision-Id header (P0-1, P1-1).
    """
    registry = get_registry()

    # Validate: exactly one mode must be used
    has_scenario = req.scenario is not None
    has_adapter = req.industry is not None and req.metrics is not None

    if has_scenario and has_adapter:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "Cannot use both 'scenario' (direct mode) and 'industry'+'metrics' (adapter mode). Choose one.",
                "error_code": "VALIDATION_ERROR",
            },
        )

    if not has_scenario and not has_adapter:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "Must provide either 'scenario' (direct mode) or 'industry'+'metrics' (adapter mode).",
                "error_code": "VALIDATION_ERROR",
            },
        )

    # Build scenario
    if has_scenario:
        # Direct mode: use the provided scenario dict
        scenario = req.scenario
    else:
        # Adapter mode: build scenario via MetricAdapter
        adapter = registry.get(req.industry)
        if adapter is None:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "message": f"Unregistered adapter: '{req.industry}'. Registered adapters: {registry.list_industries()}",
                    "error_code": "ADAPTER_NOT_FOUND",
                },
            )

        # Validate required metrics
        missing = adapter.validate_metrics(req.metrics)
        if missing:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "message": f"Missing required metrics for '{req.industry}': {missing}. Required: {adapter.required_metrics}",
                    "error_code": "VALIDATION_ERROR",
                },
            )

        # Build scenario (include_input_metrics defaults to false, P1-5 privacy minimization)
        scenario = adapter.to_scenario(
            req.metrics,
            simulation_id=req.simulation_id,
            input_query=req.input_query,
            sensitivity_level=req.sensitivity_level,
            enterprise_id=req.enterprise_id,
            rule_version=req.rule_version,
            include_input_metrics=req.include_input_metrics,
        )

    # Run simulation
    try:
        result = run_simulation(scenario, seed=req.seed)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": f"Simulation error: {str(e)}",
                "error_code": "SIMULATION_ERROR",
            },
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "message": f"Internal simulation error: {str(e)}",
                "error_code": "INTERNAL_ERROR",
            },
        )

    if req.subject_declaration is not None:
        try:
            declaration, warnings = normalize_declaration(req.subject_declaration)
        except SubjectDeclarationError as exc:
            raise HTTPException(status_code=422, detail={"message": str(exc), "error_code": exc.code})
        result["subject_ref"] = subject_ref(declaration)
        if warnings:
            result["subject_declaration_warnings"] = warnings

    # v0.6 rc2 fix MH-BUG-v0.6-001: inject input_metrics into result when include_input_metrics=true
    # Ensures X-Input-Metrics-Persisted header / API response body / DB result_json are all consistent.
    # run_simulation() output does not include input_metrics (only in scenario._adapter),
    # so we explicitly inject it to make persisted data match the header declaration.
    if has_adapter and req.include_input_metrics:
        adapter_meta = scenario.get("_adapter", {})
        if "input_metrics" in adapter_meta:
            result["input_metrics"] = adapter_meta["input_metrics"]

    # Generate decision_id (P0-1: strictly separated from runestone_id)
    decision_id = _generate_decision_id(scenario, req.seed, result.get("subject_ref"))

    # v0.6: Persist to SQLite (replaces v0.5 in-memory cache)
    runestone_id = result.get("runestone", {}).get("runestone_id", "")
    app = request.app
    storage = getattr(app.state, "storage", None)

    if storage:
        try:
            storage.save_decision(
                decision_id=decision_id,
                simulation_id=req.simulation_id or result.get("simulation_id", ""),
                runestone_id=runestone_id,
                result=result,
                adapter=req.industry,
                seed=req.seed,
            )
        except Exception as e:
            # NFR-06/NFR-15: storage write failure returns structured 500, no simulation result
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "message": "Storage write failed",
                    "error_code": "STORAGE_ERROR",
                    "storage_detail": str(e),
                },
            )

    # Set metadata headers (P1-1: metadata in headers, not body)
    # NFR-16: X-Input-Metrics-Persisted
    _set_metadata_headers(
        response,
        decision_id=decision_id,
        input_metrics_persisted=req.include_input_metrics,
    )

    # Return raw simulation result (strictly CLI-compatible, no envelope)
    return result


# ============================================================
# 端点 3: POST /api/v1/runestone
# ============================================================

@router.post("/runestone")
async def create_runestone(req: RunestoneRequest, request: Request, response: Response):
    """
    Standalone runestone generation endpoint.

    Bypasses the full simulation pipeline and directly creates a runestone audit token.
    Response body equals Runestone.to_dict() output.
    """
    # Validate reason fields
    if "enterprise_id" not in req.reason or "rule_version" not in req.reason:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "reason must contain 'enterprise_id' and 'rule_version' fields.",
                "error_code": "VALIDATION_ERROR",
            },
        )

    # Validate risk_vector (P1-3: validation failure returns 422, not bare 500)
    _validate_risk_vector(req.risk_vector)

    # Construct objects
    try:
        reason_field = ReasonField(
            enterprise_id=req.reason["enterprise_id"],
            rule_version=req.reason["rule_version"],
        )
        risk_vector = RiskVector(**req.risk_vector)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": f"Failed to construct runestone components: {str(e)}",
                "error_code": "VALIDATION_ERROR",
            },
        )

    # Generate deterministic runestone_id (if seed provided)
    import numpy as np
    np.random.seed(req.seed)

    runestone_id = None
    if req.seed is not None:
        # Use deterministic ID generation
        payload = json.dumps(
            {
                "decision": req.decision,
                "reason": str(reason_field),
                "risk_vector": risk_vector.to_dict(),
                "seed": req.seed,
            },
            ensure_ascii=False,
            sort_keys=True,
        ).encode("utf-8")
        runestone_id = f"RS_{hashlib.sha256(payload).hexdigest()[:16]}"

    # Deterministic timestamp
    from simulate import DETERMINISTIC_UNIX_TS
    timestamp = DETERMINISTIC_UNIX_TS + float(req.seed)

    runestone = Runestone.create(
        decision=req.decision,
        reason=str(reason_field),
        risk_vector=risk_vector,
        parent=req.parent_runestone,
        agents=req.agent_trail,
        ess_data=req.ess_snapshot,
        runestone_id=runestone_id,
        timestamp=timestamp,
    )

    _set_metadata_headers(response)

    runestone_dict = runestone.to_dict()

    # v0.6: Persist standalone runestone (decision_id is NULL)
    app = request.app
    storage = getattr(app.state, "storage", None)
    if storage:
        rs_id = runestone_dict.get("runestone_id", "")
        if rs_id:
            try:
                storage.save_standalone_runestone(
                    runestone_id=rs_id,
                    runestone_data=runestone_dict,
                    parent_runestone=req.parent_runestone,
                )
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail={
                        "message": "Storage write failed",
                        "error_code": "STORAGE_ERROR",
                        "storage_detail": str(e),
                    },
                )

    return runestone_dict


# ============================================================
# 端点 4: GET /api/v1/decisions/{decision_id}
# ============================================================

@router.get("/decisions/{decision_id}")
async def get_decision(decision_id: str, request: Request, response: Response):
    """
    Decision record lookup endpoint.

    v0.6: Reads from SQLite (replaces v0.5 in-memory dict). Survives service restart.
    """
    app = request.app
    storage = getattr(app.state, "storage", None)

    result = None
    if storage:
        result = storage.get_decision(decision_id)

    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "message": f"Decision '{decision_id}' not found.",
                "error_code": "NOT_FOUND",
            },
        )

    _set_metadata_headers(response, decision_id=decision_id)

    # Return the persisted raw result (consistent with /evaluate response)
    return result


# ============================================================
# Endpoint 5: GET /api/v1/audit/decisions — Decision audit list (v0.6)
# ============================================================

@router.get("/audit/decisions")
async def list_decisions(
    request: Request,
    response: Response,
    limit: int = 20,
    offset: int = 0,
    adapter: Optional[str] = None,
    since: Optional[str] = None,
):
    """
    v0.6: Paginated decision list query.

    Query parameters:
        limit: page size (1-100, default 20)
        offset: offset (default 0)
        adapter: filter by adapter (optional)
        since: UTC ISO 8601 start time (optional)
    """
    _set_metadata_headers(response)

    if limit < 1 or limit > 100:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "limit must be between 1 and 100",
                "error_code": "VALIDATION_ERROR",
            },
        )
    if offset < 0:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "offset must be >= 0",
                "error_code": "VALIDATION_ERROR",
            },
        )

    # Validate since format if provided
    if since:
        try:
            datetime.fromisoformat(since.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "message": f"Invalid 'since' format: {since}, use UTC ISO 8601",
                    "error_code": "VALIDATION_ERROR",
                },
            )

    storage = request.app.state.storage
    return storage.list_decisions(limit=limit, offset=offset, adapter=adapter, since=since)


# ============================================================
# Endpoint 6: GET /api/v1/audit/runestones — Runestone audit list (v0.6)
# ============================================================

@router.get("/audit/runestones")
async def list_runestones(
    request: Request,
    response: Response,
    limit: int = 20,
    offset: int = 0,
    since: Optional[str] = None,
):
    """
    v0.6: Runestone list query.

    Query parameters:
        limit: page size (1-100, default 20)
        offset: offset (default 0)
        since: UTC ISO 8601 start time (optional)
    """
    _set_metadata_headers(response)

    if limit < 1 or limit > 100:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "limit must be between 1 and 100",
                "error_code": "VALIDATION_ERROR",
            },
        )
    if offset < 0:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "offset must be >= 0",
                "error_code": "VALIDATION_ERROR",
            },
        )

    if since:
        try:
            datetime.fromisoformat(since.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "message": f"Invalid 'since' format: {since}, use UTC ISO 8601",
                    "error_code": "VALIDATION_ERROR",
                },
            )

    storage = request.app.state.storage
    return storage.list_runestones(limit=limit, offset=offset, since=since)


# ============================================================
# Endpoint 7: GET /api/v1/audit/runestones/{runestone_id} — Single runestone lookup (v0.6)
# ============================================================

@router.get("/audit/runestones/{runestone_id}")
async def get_runestone(runestone_id: str, request: Request, response: Response):
    """
    v0.6: Look up a runestone by runestone_id.

    Can query runestones auto-generated by evaluate and standalone POST /runestone runestones.
    """
    _set_metadata_headers(response)

    storage = request.app.state.storage
    result = storage.get_runestone(runestone_id)

    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "message": f"Runestone '{runestone_id}' not found.",
                "error_code": "NOT_FOUND",
            },
        )

    return result


# ============================================================
# Endpoint 8: DELETE /api/v1/audit/decisions — Data cleanup (v0.6, with safety valve)
# ============================================================

@router.delete("/audit/decisions")
async def delete_data(
    request: Request,
    response: Response,
    confirm: Optional[str] = None,
    before: Optional[str] = None,
    all: Optional[str] = None,
):
    """
    v0.6: Data cleanup endpoint (with safety valve).

    Safety valve rules:
    1. Must pass confirm=true, otherwise 422
    2. Must pass before=<UTC ISO> or all=true, otherwise 422
    3. Returns 403 when bind_host is not 127.0.0.1/localhost
    """
    _set_metadata_headers(response)

    # Safety valve 1: non-local binding check
    bind_host = getattr(request.app.state, "bind_host", "127.0.0.1")
    if bind_host not in ("127.0.0.1", "localhost"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "message": "DELETE endpoint disabled on non-local bind",
                "error_code": "FORBIDDEN",
            },
        )

    # Safety valve 2: confirm parameter
    if confirm != "true":
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "Missing confirm=true parameter",
                "error_code": "VALIDATION_ERROR",
            },
        )

    # Safety valve 3: before or all parameter
    if all == "true":
        storage = request.app.state.storage
        return storage.delete_data(all_data=True)
    elif before:
        try:
            datetime.fromisoformat(before.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "message": f"Invalid 'before' format: {before}, use UTC ISO 8601",
                    "error_code": "VALIDATION_ERROR",
                },
            )
        storage = request.app.state.storage
        return storage.delete_data(before=before)
    else:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "Must provide before=<UTC ISO> or all=true",
                "error_code": "VALIDATION_ERROR",
            },
        )


# ============================================================
# 端点 9: POST /api/v1/envelope  (v1.2 Observer I/O contract)
# ============================================================

@router.post("/envelope")
async def envelope_run(req: EnvelopeRequest, response: Response):
    """
    v1.2 Observer Input/Output Envelope endpoint.

    Request body = v1.2 Input Envelope (EnvelopeRequest.input_envelope).
    Response body = v1.2 Output Envelope, produced by the SAME
    `envelope.run_envelope` function the CLI uses, so REST and CLI are
    byte-for-byte equivalent (FR-03 / AC-01). Pure local computation; no
    network calls. L4_CANDIDATE references are carried but never produce
    external effect (external_effect is always false in v1.2).
    """
    _set_metadata_headers(response)
    try:
        out = envelope_mod.run_envelope(req.input_envelope)
    except envelope_mod.InputEnvelopeError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": f"Input Envelope invalid: {exc}",
                "error_code": "INPUT_ENVELOPE_INVALID",
                "errors": exc.errors,
            },
        )
    ok, errors = envelope_mod.validate_output_envelope(out)
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "message": f"Output Envelope failed schema validation: {errors}",
                "error_code": "OUTPUT_ENVELOPE_INVALID",
            },
        )
    return out


# ============================================================
# v1.3 additive endpoints (Profile / Policy load) — NOT FOR PRODUCTION / local only
# ============================================================

@router.post("/profile/load")
async def profile_load(req: ProfileLoadRequest, response: Response):
    """
    v1.3 additive endpoint: validate + ingest a Profile into the shared registry.

    No authentication is added (consistent with the v1.2 local / offline posture).
    Returns the resolved ``id@version`` key plus the recomputed digest.
    """
    _set_metadata_headers(response)
    reg = get_profile_registry()
    try:
        key = reg.ingest(req.profile)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": str(exc), "error_code": "PROFILE_INVALID"},
        )
    except ProfileIntegrityError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": str(exc), "error_code": "PROFILE_INTEGRITY"},
        )
    return {
        "key": key,
        "profile_id": req.profile.get("id"),
        "version": req.profile.get("version"),
    }


@router.get("/profile/{profile_id}")
async def profile_get(profile_id: str, response: Response, version: Optional[str] = None):
    """
    v1.3 additive endpoint: fetch a Profile by id (optionally pinned version).
    """
    _set_metadata_headers(response)
    reg = get_profile_registry()
    try:
        obj = reg.get(profile_id, version)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"message": f"profile {profile_id} not found", "error_code": "NOT_FOUND"},
        )
    return obj


@router.post("/policy/load")
async def policy_load(req: PolicyLoadRequest, response: Response):
    """
    v1.3 additive endpoint: validate a governance policy dict (never executed).

    The Observer only COMPATIBLES with, never FORGES, auth; a policy is validated
    for schema completeness but is not run by the first-generation engine.
    """
    _set_metadata_headers(response)
    policy = req.policy
    for field in ("policy_id", "version", "source", "approved_by", "change_log", "rules", "default"):
        if field not in policy:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={"message": f"policy missing required field: {field}", "error_code": "POLICY_INVALID"},
            )
    return {"policy_id": policy.get("policy_id"), "version": policy.get("version")}


# ============================================================
# v1.4 additive endpoints — Replay & Audit (NOT FOR PRODUCTION / local only)
# ============================================================
#
# These six endpoints are purely ADDITIVE. They reuse the exact same facade
# functions the CLI uses (record_evaluation / ReplayEngine / AuditExporter /
# IntegrityChecker), so REST and CLI are byte-for-byte equivalent (FR-03 /
# AC-01). No pre-v1.4 endpoint or model is modified.


def _get_eval_store():
    """Return the v1.4 evaluation-event store (default append-only SQLite)."""
    from src.governance_chain import replay_store as rs_mod

    return rs_mod.get_default_store()


@router.post("/evaluation/record")
async def evaluation_record(req: EvaluationRecordRequest, response: Response):
    """
    v1.4 additive endpoint: analyze an Input Envelope and append an immutable
    EvaluationEvent (FR-01 / FR-03).

    The response body is the audited v1.2 Output Envelope with a *real,
    resolvable* ``replay_ref`` (red-line: never forged). The v1.2/v1.3 direct
    ``/envelope`` path is untouched and still emits ``replay_ref=None``.
    """
    _set_metadata_headers(response)
    from src.governance_chain import evaluation_event as ee_mod
    from src.governance_chain.evaluation_event import EventIntegrityError

    store = _get_eval_store()
    env = req.input_envelope
    try:
        out = ee_mod.record_evaluation(
            env,
            store=store,
            clock=req.clock or None,
            externalize_input=req.externalize_input,
        )
    except EventIntegrityError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": str(exc), "error_code": "EVENT_INTEGRITY"},
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": str(exc), "error_code": "ENVELOPE_INVALID"},
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"message": f"Record failed: {exc}", "error_code": "INTERNAL_ERROR"},
        )
    response.headers["X-Evaluation-Event-Id"] = out.get("replay_ref", {}).get("event_id", "")
    return out


@router.post("/replay")
async def replay(req: ReplayRequest, response: Response):
    """
    v1.4 additive endpoint: replay a ReplayBundle (or a stored event by id) into
    a brand-new REPLAY EvaluationEvent — the original is never mutated (FR-05 /
    FR-06). ``policy_version`` overrides the policy binding (FR-05).

    Replays only APPEND; an original event's hash never changes (red-line).
    """
    _set_metadata_headers(response)
    from src.governance_chain import replay as replay_mod
    from src.governance_chain import replay_bundle as rb_mod
    from src.governance_chain.replay_bundle import ReplayDependencyError

    if req.replay_mode not in ("EXACT", "SEMANTIC", "EXPLANATORY"):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": f"unknown replay_mode '{req.replay_mode}'",
                "error_code": "VALIDATION_ERROR",
            },
        )

    store = _get_eval_store()
    engine = replay_mod.ReplayEngine(store)

    if req.bundle is not None:
        bundle = rb_mod.ReplayBundle.from_dict(req.bundle)
    elif req.event_id is not None:
        ev = store.get(req.event_id)
        if ev is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "message": f"event '{req.event_id}' not found",
                    "error_code": "NOT_FOUND",
                },
            )
        bundle = rb_mod.ReplayBundle.from_event(ev)
    else:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "message": "must provide 'bundle' or 'event_id'",
                "error_code": "VALIDATION_ERROR",
            },
        )

    try:
        new_event = engine.replay(
            bundle,
            policy_version=req.policy_version or None,
            replay_mode=req.replay_mode,
        )
    except ReplayDependencyError as exc:
        # NFR-02: explicit, never-guess dependency failure — NOT a silent success.
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": str(exc), "error_code": "REPLAY_DEPENDENCY"},
        )
    return new_event


@router.get("/evaluation/events/{event_id}")
async def get_evaluation_event(event_id: str, response: Response):
    """
    v1.4 additive endpoint: fetch a single EvaluationEvent by id.
    """
    _set_metadata_headers(response)
    store = _get_eval_store()
    ev = store.get(event_id)
    if ev is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"message": f"event '{event_id}' not found", "error_code": "NOT_FOUND"},
        )
    return ev


@router.get("/evaluation/events")
async def list_evaluation_events(
    response: Response,
    limit: int = 100,
    offset: int = 0,
    event_type: Optional[str] = None,
):
    """
    v1.4 additive endpoint: list recorded EvaluationEvents (append-only chain).
    """
    _set_metadata_headers(response)
    if limit < 1 or limit > 1000:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": "limit must be between 1 and 1000", "error_code": "VALIDATION_ERROR"},
        )
    if offset < 0:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": "offset must be >= 0", "error_code": "VALIDATION_ERROR"},
        )
    store = _get_eval_store()
    events = store.list_events(limit=limit, offset=offset, event_type=event_type)
    return {
        "items": events,
        "total": store.count(),
        "returned": len(events),
        "limit": limit,
        "offset": offset,
    }


@router.post("/audit/export")
async def audit_export(req: AuditExportRequest, response: Response):
    """
    v1.4 additive endpoint: export the append-only chain as canonical JSONL
    (FR-09). Returns the temp file path plus the exact JSONL content.
    """
    _set_metadata_headers(response)
    import tempfile

    from src.governance_chain import audit as audit_mod

    store = _get_eval_store()
    events = store.list_events(limit=req.limit)
    fd, path = tempfile.mkstemp(prefix="fse_audit_", suffix=".jsonl")
    import os

    os.close(fd)
    audit_mod.AuditExporter.export_range(events, path)
    with open(path, encoding="utf-8") as handle:
        content = handle.read()
    return {"path": path, "count": len(events), "content": content}


@router.post("/audit/verify")
async def audit_verify(response: Response):
    """
    v1.4 additive endpoint: verify the append-only chain integrity, i.e. tamper
    detection (FR-09). Returns {ok, tampered, count, chain_verified}.
    """
    _set_metadata_headers(response)
    from src.governance_chain import audit as audit_mod

    store = _get_eval_store()
    ok, tampered = audit_mod.IntegrityChecker.verify_chain(store)
    return {
        "ok": ok,
        "chain_verified": ok,
        "tampered": tampered,
        "count": store.count(),
    }


# ============================================================
# v1.5 enterprise_pilot additive endpoints (auth-gated)
# ============================================================
#
# These six endpoints are purely ADDITIVE and auth-gated via RBAC (Operator /
# Service Principal only). They reuse the exact same facade functions the CLI
# and the v1.5 unit suite use (record_review / run_walkthrough / ConnectorContract
# / health / metrics_snapshot), so REST == CLI == unit. No pre-v1.5 endpoint,
# model, or behaviour is modified (red-line: v1.4 black-box 9/9 must stay green).
#
# Auth gate (closed decision #7): only the NEW v1.5 endpoints require a Bearer
# token. v1.4 endpoints are intentionally left ungated to preserve their
# no-auth black-box contract.

_PILOT_RBAC = None


def _get_pilot_rbac():
    """Lazily build the v1.5 RBAC engine (module-level singleton)."""
    global _PILOT_RBAC
    if _PILOT_RBAC is None:
        from src.enterprise_pilot import RbacEngine, TokenRegistry

        _PILOT_RBAC = RbacEngine(TokenRegistry())
    return _PILOT_RBAC


def _pilot_authenticate(request: Request):
    """Extract Bearer token, authenticate via _PILOT_RBAC. 401 on failure."""
    from src.enterprise_pilot import AuthorizationError, SubjectAsPrincipalError

    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"message": "missing bearer token", "error_code": "UNAUTHENTICATED"},
        )
    token = auth[len("Bearer "):].strip()
    rbac = _get_pilot_rbac()
    try:
        principal = rbac.authenticate(token)
    except (AuthorizationError, SubjectAsPrincipalError):
        # SubjectAsPrincipalError == using an ObservedSubject as identity (AC-06)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"message": "authentication failed (unknown token or subject used as identity)",
                    "error_code": "UNAUTHENTICATED"},
        )
    return principal


def _pilot_require(principal, action: str):
    rbac = _get_pilot_rbac()
    if not rbac.authorize(principal, action):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"message": f"not authorized for '{action}'", "error_code": "FORBIDDEN"},
        )


@router.post("/pilot/auth/verify")
async def pilot_auth_verify(request: Request, response: Response,
                             req: PilotAuthVerifyRequest):
    """v1.5: authenticate a pre-shared reference token; return principal + perms."""
    _set_metadata_headers(response)
    principal = _pilot_authenticate(request)
    return {
        "authenticated": True,
        "principal_id": principal.principal_id,
        "kind": principal.kind,
        "roles": principal.role_names(),
        "permissions": sorted(principal.permissions()),
    }


@router.post("/pilot/review")
async def pilot_review(request: Request, response: Response, req: PilotReviewRequest):
    """v1.5: record a human review bound to a real EvaluationEvent (red-line #8)."""
    _set_metadata_headers(response)
    principal = _pilot_authenticate(request)
    _pilot_require(principal, "review:write")
    from src.enterprise_pilot import record_review

    event_ref = {
        "event_id": req.event_id,
        "event_digest": req.event_digest,
        "bundle_ref": req.bundle_ref,
    }
    try:
        rec = record_review(
            event_ref, req.action, req.reviewer_principal_id,
            comment=req.comment, idempotency_key=req.idempotency_key,
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"message": str(exc), "error_code": "REVIEW_ERROR"},
        )
    return rec


@router.get("/pilot/health")
async def pilot_health(request: Request, response: Response):
    """v1.5: enterprise_pilot health probe (requires metrics:read)."""
    _set_metadata_headers(response)
    principal = _pilot_authenticate(request)
    _pilot_require(principal, "metrics:read")
    from src.enterprise_pilot import health

    return health({"principal": principal.principal_id})


@router.get("/pilot/metrics")
async def pilot_metrics(request: Request, response: Response):
    """v1.5: metrics snapshot (requires metrics:read)."""
    _set_metadata_headers(response)
    principal = _pilot_authenticate(request)
    _pilot_require(principal, "metrics:read")
    from src.enterprise_pilot import metrics_snapshot

    return metrics_snapshot()


@router.post("/pilot/connector/export")
async def pilot_connector_export(request: Request, response: Response,
                                 req: PilotConnectorExportRequest):
    """v1.5: return a connector contract payload; business write-back stays OFF."""
    _set_metadata_headers(response)
    principal = _pilot_authenticate(request)
    _pilot_require(principal, "audit:read")
    from src.enterprise_pilot import ConnectorContract, emit_contract

    contract = ConnectorContract(req.name, write_enabled=False)
    return emit_contract(contract, req.kind, req.payload)


@router.post("/pilot/deploy/walkthrough")
async def pilot_deploy_walkthrough(request: Request, response: Response,
                                   req: PilotDeployWalkthroughRequest):
    """v1.5: non-author deploy walkthrough (requires deploy:read)."""
    _set_metadata_headers(response)
    principal = _pilot_authenticate(request)
    _pilot_require(principal, "deploy:read")
    from src.enterprise_pilot import run_walkthrough

    return run_walkthrough(req.repo_root).to_dict()
