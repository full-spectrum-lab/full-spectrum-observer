# Foundation Kernel Contract Bundle v1.0 Design Baseline

Status: APPROVED_DESIGN_BASELINE

This bundle contains 12 self-contained JSON Schema Draft 2020-12 contracts,
stable `$id` values, validated example instances, CASE005 synthetic artifacts,
digest rules, reason codes, DB draft, and the Engine Worker protocol.

Important:
- Schema status is a version design baseline, not a public STABLE protocol.
- Engine packaged-artifact digest is `PENDING_VG3`; no fake zero digest is used.
- Runtime external `$ref` is intentionally not used in v0.1.0-alpha.
- All self-containing digest algorithms are defined in `protocols/digest-rules-v1.md`.
