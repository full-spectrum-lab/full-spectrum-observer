# Engine Worker Protocol v1

Status: DRAFT FOR VG2 REVIEW

Transport: one UTF-8 compact JSON object on stdin; one UTF-8 compact JSON object on stdout. Diagnostics go only to stderr. The Host does not invoke a shell.

## Request

- protocol: `fs-observer-engine-facade/1`
- request_id: UUID
- operation: `evaluate`
- engine.version: `v1.0.0`
- engine.commit: `09062bae2c7608bda79ee4bfde5779109e8e6197`
- seed: integer
- fixed_time_utc: RFC3339 UTC
- scenario: direct Engine scenario object
- output_serialization: `FSE-PYJSON-1`

## Response

- status: SUCCESS / ERROR / CANCELLED / TIMED_OUT
- engine version and commit must echo the pinned values
- SUCCESS includes output, output_sha256 and `FSE-PYJSON-1`
- ERROR includes a stable reason code and redacted message

## Limits

- request <= 1 MiB
- stdout response <= 10 MiB
- one response line only
- default timeout 30 seconds; range 1-300 seconds
- no network listener, no Engine API server, no Engine SQLite persistence
