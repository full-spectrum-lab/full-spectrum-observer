-- Observer System v0.1.0-alpha Foundation Kernel
-- DRAFT FOR VG2 REVIEW; not an implementation migration.
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = DELETE;
PRAGMA busy_timeout = 5000;

CREATE TABLE schema_versions (
  schema_id TEXT PRIMARY KEY,
  applied_at_utc TEXT NOT NULL,
  checksum TEXT NOT NULL CHECK(length(checksum)=64)
);

CREATE TABLE operations (
  operation_id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL,
  trace_id TEXT NOT NULL,
  state TEXT NOT NULL,
  reason_json TEXT NOT NULL DEFAULT '[]',
  timeout_seconds INTEGER NOT NULL CHECK(timeout_seconds BETWEEN 1 AND 300),
  started_at_utc TEXT NOT NULL,
  updated_at_utc TEXT NOT NULL,
  completed_at_utc TEXT NULL
);
CREATE INDEX ix_operations_state ON operations(state);
CREATE UNIQUE INDEX ux_operations_request_id ON operations(request_id);

CREATE TABLE idempotency_records (
  idempotency_key TEXT PRIMARY KEY,
  request_fingerprint TEXT NOT NULL CHECK(length(request_fingerprint)=64),
  operation_id TEXT NOT NULL REFERENCES operations(operation_id),
  observation_id TEXT NULL,
  created_at_utc TEXT NOT NULL
);

CREATE TABLE runtime_snapshots (
  snapshot_id TEXT PRIMARY KEY,
  snapshot_json TEXT NOT NULL,
  snapshot_sha256 TEXT NOT NULL CHECK(length(snapshot_sha256)=64),
  created_at_utc TEXT NOT NULL
);
CREATE TRIGGER runtime_snapshots_no_update BEFORE UPDATE ON runtime_snapshots
BEGIN SELECT RAISE(ABORT, 'SNAPSHOT_IMMUTABLE'); END;
CREATE TRIGGER runtime_snapshots_no_delete BEFORE DELETE ON runtime_snapshots
BEGIN SELECT RAISE(ABORT, 'SNAPSHOT_IMMUTABLE'); END;

CREATE TABLE artifacts (
  artifact_id TEXT PRIMARY KEY,
  media_type TEXT NOT NULL,
  sha256 TEXT NOT NULL UNIQUE CHECK(length(sha256)=64),
  size_bytes INTEGER NOT NULL CHECK(size_bytes>=0),
  relative_path TEXT NOT NULL,
  classification TEXT NOT NULL,
  created_at_utc TEXT NOT NULL
);

CREATE TABLE observations (
  observation_id TEXT PRIMARY KEY,
  operation_id TEXT NOT NULL UNIQUE REFERENCES operations(operation_id),
  request_id TEXT NOT NULL,
  trace_id TEXT NOT NULL,
  status TEXT NOT NULL,
  input_sha256 TEXT NOT NULL CHECK(length(input_sha256)=64),
  canonical_context_sha256 TEXT NULL,
  snapshot_id TEXT NOT NULL REFERENCES runtime_snapshots(snapshot_id),
  output_artifact_id TEXT NULL REFERENCES artifacts(artifact_id),
  audit_head TEXT NOT NULL CHECK(length(audit_head)=64),
  created_at_utc TEXT NOT NULL,
  updated_at_utc TEXT NOT NULL
);
CREATE INDEX ix_observations_trace ON observations(trace_id);
CREATE INDEX ix_observations_status ON observations(status);

CREATE TABLE audit_events (
  sequence_no INTEGER PRIMARY KEY,
  event_id TEXT NOT NULL UNIQUE,
  stream_id TEXT NOT NULL DEFAULT 'GLOBAL' CHECK(stream_id='GLOBAL'),
  event_type TEXT NOT NULL,
  occurred_at_utc TEXT NOT NULL,
  actor_type TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  observation_id TEXT NULL,
  operation_id TEXT NULL,
  trace_id TEXT NOT NULL,
  payload_digest TEXT NOT NULL CHECK(length(payload_digest)=64),
  payload_media_type TEXT NOT NULL,
  serialization_id TEXT NOT NULL CHECK(serialization_id='FS-OBS-CANON-1'),
  previous_hash TEXT NOT NULL CHECK(length(previous_hash)=64),
  event_hash TEXT NOT NULL UNIQUE CHECK(length(event_hash)=64)
);
CREATE INDEX ix_audit_trace ON audit_events(trace_id);
CREATE TRIGGER audit_events_no_update BEFORE UPDATE ON audit_events
BEGIN SELECT RAISE(ABORT, 'AUDIT_EVENT_IMMUTABLE'); END;
CREATE TRIGGER audit_events_no_delete BEFORE DELETE ON audit_events
BEGIN SELECT RAISE(ABORT, 'AUDIT_EVENT_IMMUTABLE'); END;

CREATE TABLE instance_lock (
  lock_id INTEGER PRIMARY KEY CHECK(lock_id=1),
  owner_pid INTEGER NOT NULL,
  started_at_utc TEXT NOT NULL,
  package_sha256 TEXT NOT NULL CHECK(length(package_sha256)=64)
);
